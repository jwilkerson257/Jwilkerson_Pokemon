﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _P_Pokemon
{
    public class Pokemon
    {
        public string Name { get; set; }
        public string url { get; set; }

        public Pokemon(string name, int weight, int height, string url)
        {
            Name = name;
            this.url = url;
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public class PokemonAPI
    {
        public List<Pokemon> results { get; set; }
    }

    public class Sprite
    {
        public string back_default;
        public string front_default;

        public Sprite()
        {
        
        }
    }

    public class Data
    {
        public int height { get; set; }
        public int weight { get; set; }
        public Sprite sprites { get; set; }

        public Data()
        {
            height = 0;
            weight = 0;
            sprites = new Sprite();
        }
        public Data(int height, int weight, string sprite)
        {
            height = this.height;
            weight = this.weight;
            //Sprite = sprite;
        }

    }

}
