﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _P_Pokemon
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Sprite sprite;
        public MainWindow()
        {
            InitializeComponent();



            using (var client = new HttpClient())
            {

                string jsonData = client.GetStringAsync("https://pokeapi.co/api/v2/pokemon?offset=00&limit=1200").Result;

                PokemonAPI api = JsonConvert.DeserializeObject<PokemonAPI>(jsonData);

                foreach (Pokemon item in api.results)
                {
                    comboPokemon.Items.Add(item);
                }


            }




        }

        private void comboPokemon_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            Pokemon selected = (Pokemon)comboPokemon.SelectedItem;

            using (var client = new HttpClient())
            {

                string jsonData = client.GetStringAsync(selected.url).Result;

                Data api = JsonConvert.DeserializeObject<Data>(jsonData);
                sprite = api.sprites;
                imgSprite.Source = new BitmapImage(new Uri(api.sprites.front_default));


                txtHeight.Text = api.height + "";
                txtWeight.Text = api.weight + "";

                

            }


        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            imgSprite.Source = new BitmapImage(new Uri(sprite.back_default));
        }

        private void btnFront_Click(object sender, RoutedEventArgs e)
        {
            imgSprite.Source = new BitmapImage(new Uri(sprite.front_default));
        }
    }
}
